# Tarefa - A02 - HTML - Filmes
- Escolha 5 filmes de sua preferência, baixe as figuras das capas dos respectivos filmes (na web) e os textos de suas sinópses.
- Baseado no conteúdo da aula A02 HTML Básico, crie um arquivo de nome index.html, que deve ser editado da seguinte forma:
- No início da tua página Web, deverá existir links, um para cada filme, posicionados um embaixo do outro, como uma espécie de barra de navegação. Ao clicar no link do filme, o usuário deve ser redirecionado à parte da tua página Web onde estão as informações do respectivo filme.  
- Abaixo da barra de navegação, insira o título do filme.
- Abaixo do título, insira a figura da capa correspondente. Utilize a tag <picture> ao invés de simplesmente <img>.
- Embaixo da capa, insira a sinópse.
- Depois da sinópse, insira o título do próximo filme e repita os passos 3, 4 e 5 até que todos os filmes sejam inseridos.